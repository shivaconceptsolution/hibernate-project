package annotationexample;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import scs.Job;

public class AddStudent {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
	    SessionFactory sf = cfg.buildSessionFactory();
	    Session s = sf.openSession();
	    Transaction tx = s.beginTransaction();
	    Student st = new Student();
	    st.setRno(1001);
	    st.setSname("Manish Kumar");
	    st.setBranch("cs");
	    st.setFees(45000);
	    s.save(st);
	    tx.commit();
	    s.close();

	}

}
