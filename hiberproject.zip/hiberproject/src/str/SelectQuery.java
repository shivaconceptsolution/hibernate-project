package str;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SelectQuery {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		  cfg.configure("hibernate.cfg.xml");
		  SessionFactory sf = cfg.buildSessionFactory();
		  Session s = sf.openSession();
		  Query q = s.createQuery("select v.vendorId ,v.vendorName ,c.customerName from Vendor v inner join v.children c");
		  List lst = q.list();
		  Iterator it = lst.iterator();
		  while(it.hasNext())
		  {
		   Object arr[] = (Object[])it.next();
		   System.out.println(arr[0] +" "+arr[1] + " "+arr[2]);
		  }
          sf.close();

	}

}
