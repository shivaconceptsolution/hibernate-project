package str;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AddVendorCustomer {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
	    SessionFactory sf = cfg.buildSessionFactory();
	    Session s = sf.openSession();
	    Transaction tx = s.beginTransaction();
	    Customer c1 = new Customer();
	    c1.setCustomerId(1001);
	    c1.setCustomerName("Nitesh");
	    Customer c2 = new Customer();
	    c2.setCustomerId(1002);
	    c2.setCustomerName("Ramesh");
	    Vendor v1 = new Vendor();
	    v1.setVendorId(101);
	    v1.setVendorName("TATA");
	    Set st = new HashSet<>();
	    st.add(c1);
	    st.add(c2);
	    v1.setChildren(st);
	    s.save(v1);
	    tx.commit();
	    sf.close();


	}

}
