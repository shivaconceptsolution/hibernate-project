package scs;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

public class CriteriaExample {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
	    SessionFactory sf = cfg.buildSessionFactory();
	    Session s = sf.openSession();
	    Criteria q = s.createCriteria(Job.class);
	    Criterion res = Restrictions.gt("jobid",5);
	    q.add(res);
	    List lst = q.list();
	    Iterator it = lst.iterator();
	    while(it.hasNext())
	    {
	    	Job j = (Job) it.next();
	    	System.out.println(j.getJobid() + " "+j.getJobtitle());
	    }
	    s.close();  

	}

}
