package scs;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class ProjectionExample {
public static void main(String args[])
{
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
    SessionFactory sf = cfg.buildSessionFactory();
    Session s = sf.openSession();
    Criteria q = s.createCriteria(Job.class);
    //q.setProjection(Projections.property("jobid"));
    ProjectionList pl = Projections.projectionList();
    pl.add(Projections.property("jobid"));
    pl.add(Projections.property("jobtitle"));
    q.setProjection(pl);
    List lst = q.list();
    Iterator it = lst.iterator();
    while(it.hasNext())
    {
    //	Job j = (Job) it.next();
    //	System.out.println(j.getJobid() + " "+j.getJobtitle());
    //	Object o = it.next();
    //	System.out.println(o);
    	Object arr[] = (Object[])it.next();
        System.out.println(arr[0] + " "+arr[1]);
    }
    s.close();  

}
}
