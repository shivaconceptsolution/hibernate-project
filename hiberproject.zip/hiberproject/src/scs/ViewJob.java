package scs;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ViewJob {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
	    SessionFactory sf = cfg.buildSessionFactory();
	    Session s = sf.openSession();
	  //  Query q = s.createQuery("from Job j"); //select * from job
	  //  Query q = s.createQuery("select j.jobid,j.jobtitle from Job j"); //select * from job
	   // Query q = s.createQuery("select j.jobid,j.jobtitle from Job j where j.jobid=?"); //select * from job
	   // q.setInteger(0,5);
	    Query q = s.createQuery("select j.jobid,j.jobtitle from Job j where j.jobid=:a and j.jobtitle=:b"); //select * from job
		q.setInteger("a",5);
		q.setString("b","Professor");
	    List lst = q.list();
	    Iterator it = lst.iterator();
	    while(it.hasNext())
	    {
	    	//Job obj =(Job) it.next();
	    	//System.out.println(obj.getJobid() + " "+obj.getJobtitle());
	    	  Object arr[] =(Object[])it.next();
	    	  System.out.println(arr[0] + "," + arr[1]);
	    	//System.out.println(it.next());
	    }
	    s.close();

	}

}
